Use Y to dir UP
Use H to dir DOW
Use G to dir LEFT
Use J to dir RIGHT

Use Z to Climb Up
Use X to Climb Down