package src;

import java.awt.Color;

public class Personality {

	public static int generalHappiness = BodyParts.HeadH*BodyParts.acH;
	public static int motivation = 100;
	public static boolean depressed = false;
	public static String[] phobias = {
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			"",
			""
	};
	
	public static void personalityMenu() {
		generalHappiness = BodyParts.HeadH+BodyParts.acH;
		if (generalHappiness <= 70) {
			if (Frame.phobialevel != 0) {
				Frame.phobialevel++;
				if (Frame.phobialevel == phobias.length) {
					Frame.phobialevel = 0;
				}
				switch(Frame.enemy) {
				case "TROLL":
					Frame.setAnnouncement(Color.RED, "You have Gygaphobia");
					phobias[Frame.phobialevel] = "Gygaphobia";
					break;
				case "SKELETON":
					phobias[Frame.phobialevel] = "Skelephobia";
					break;
				}
				
			} else {
				switch(Frame.enemy) {
				case "TROLL":
					Frame.setAnnouncement(Color.RED, "You have Gygaphobia");
					phobias[Frame.phobialevel] = "Gygaphobia";
					break;
				case "SKELETON":
					phobias[Frame.phobialevel] = "Skelephobia";
					break;
				}
			}
		}
		if (generalHappiness <= 60) {
			motivation -= 10;
		}
		if (motivation <= 50) {
			Frame.setAnnouncement(Color.RED, "You are depressed");
			depressed = true;
		}
		setMentality(Color.BLUE, "General Happiness: "+generalHappiness);
	}
	public static void setMentality(Color color, String text) {
		Frame.row4A.setText(text);
		Frame.row4A.setForeground(color);
	}
	public static void generateTraits() {
		
	}
}
