package src;

public class Builder {
	public static void BuildScript() throws ArrayIndexOutOfBoundsException {
		if(Frame.block == "wood") {
		switch (Frame.dir) {
			case "UP":
				switch (Main.world[Frame.y-1][Frame.x]) {
					case "♣", "▒":
						Main.world[Frame.y-1][Frame.x] = ".";
						Frame.wood++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.wood != 0 && Main.world[Frame.y-1][Frame.x] == ".") {
							Frame.wood--;
							Main.world[Frame.y-1][Frame.x] = "▒";
							Main.printWorld();
						}
						break;
				}
				break;
			case "DOWN":
				switch (Main.world[Frame.y+1][Frame.x]) {
					case "♣", "▒":
						Main.world[Frame.y+1][Frame.x] = ".";
						Frame.wood++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.wood != 0 && Main.world[Frame.y+1][Frame.x] == ".") {
							Frame.wood--;
							Main.world[Frame.y+1][Frame.x] = "▒";
							Main.printWorld();
						}
						break;
				}
				break;
			case "LEFT":
				switch (Main.world[Frame.y][Frame.x-1]) {
					case "♣", "▒":
						Main.world[Frame.y][Frame.x-1] = ".";
						Frame.wood++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.wood != 0 && Main.world[Frame.y][Frame.x-1] == ".") {
							Frame.wood--;
							Main.world[Frame.y][Frame.x-1] = "▒";
							Main.printWorld();
						}
						break;
				}
				break;
			case "RIGHT":
				switch (Main.world[Frame.y][Frame.x+1]) {
					case "♣", "▒":
						Main.world[Frame.y][Frame.x+1] = ".";
						Frame.wood++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.wood != 0 && Main.world[Frame.y][Frame.x+1] == ".") {
							Frame.wood--;
							Main.world[Frame.y][Frame.x+1] = "▒";
							Main.printWorld();
						}
						break;
				}
				break;
			
			}
		}else if (Frame.block == "shovel") {
				switch (Frame.dir) {
				case "UP":
					switch (Main.world[Frame.y-1][Frame.x]) {
						case ".":
							Main.world[Frame.y-1][Frame.x] = ">";
							Frame.dirt++;
							Main.printWorld();
							break;
						case ">":
							if (Frame.dirt != 0 && Main.world[Frame.y-1][Frame.x] == ">") {
								Frame.dirt--;
								Main.world[Frame.y-1][Frame.x] = ".";
								Main.printWorld();
							}
							break;
					}
					break;
				case "DOWN":
					switch (Main.world[Frame.y+1][Frame.x]) {
					case ".":
						Main.world[Frame.y+1][Frame.x] = ">";
						Frame.dirt++;
						Main.printWorld();
						break;
					case ">":
						if (Frame.dirt != 0 && Main.world[Frame.y+1][Frame.x] == ">") {
							Frame.dirt--;
							Main.world[Frame.y+1][Frame.x] = ".";
							Main.printWorld();
						}
						break;
				}
				break;
				case "LEFT":
					switch (Main.world[Frame.y][Frame.x-1]) {
					case ".":
						Main.world[Frame.y][Frame.x-1] = ">";
						Frame.dirt++;
						Main.printWorld();
						break;
					case ">":
						if (Frame.dirt != 0 && Main.world[Frame.y][Frame.x-1] == ">") {
							Frame.dirt--;
							Main.world[Frame.y][Frame.x-1] = ".";
							Main.printWorld();
						}
						break;
				}
				break;
				case "RIGHT":
					switch (Main.world[Frame.y][Frame.x+1]) {
					case ".":
						Main.world[Frame.y][Frame.x+1] = ">";
						Frame.dirt++;
						Main.printWorld();
						break;
					case ">":
						if (Frame.dirt != 0 && Main.world[Frame.y][Frame.x+1] == ">") {
							Frame.dirt--;
							Main.world[Frame.y][Frame.x-1] = ".";
							Main.printWorld();
						}
						break;
				}
				break;
				
				}
			} else if (Frame.block == "stone") {
				switch (Frame.dir) {
				case "UP":
					switch (Main.world[Frame.y-1][Frame.x]) {
						case "▒":
							Main.world[Frame.y-1][Frame.x] = ".";
							Frame.stone++;
							Main.printWorld();
							break;
						case ".":
							if (Frame.stone != 0 && Main.world[Frame.y-1][Frame.x] == "▒") {
								Frame.stone--;
								Main.world[Frame.y-1][Frame.x] = ".";
								Main.printWorld();
							}
							break;
					}
					break;
				case "DOWN":
					switch (Main.world[Frame.y+1][Frame.x]) {
					case "▒":
						Main.world[Frame.y+1][Frame.x] = ".";
						Frame.stone++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.stone != 0 && Main.world[Frame.y+1][Frame.x] == "▒") {
							Frame.stone--;
							Main.world[Frame.y+1][Frame.x] = ".";
							Main.printWorld();
						}
						break;
				}
				break;
				case "LEFT":
					switch (Main.world[Frame.y][Frame.x-1]) {
					case "▒":
						Main.world[Frame.y][Frame.x-1] = ".";
						Frame.stone++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.stone != 0 && Main.world[Frame.y][Frame.x-1] == "▒") {
							Frame.stone--;
							Main.world[Frame.y][Frame.x-1] = ".";
							Main.printWorld();
						}
						break;
				}
				break;
				case "RIGHT":
					switch (Main.world[Frame.y][Frame.x+1]) {
					case "▒":
						Main.world[Frame.y][Frame.x+1] = ".";
						Frame.stone++;
						Main.printWorld();
						break;
					case ".":
						if (Frame.stone != 0 && Main.world[Frame.y][Frame.x+1] == "▒") {
							Frame.stone--;
							Main.world[Frame.y][Frame.x-1] = ".";
							Main.printWorld();
						}
						break;
				}
				break;
				
				}
			}
		}
	}
