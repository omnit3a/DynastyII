package src;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	
	public static String[][] world = {
			{"@",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."},
			{".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".",".","."}
	};
	
	public static int[][] worldGasConcetration = {
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
	};
	
	public static int[][] worldLiquidConcentration = {
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
	};
	
	public static int[][] worldElevationMap = {
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
	};
	
	static Frame frame = new Frame();
	public static String out;
	
	public static void printWorld() {
		try {
		int y = 3;
		world[Frame.y][Frame.x] = "@";
		Frame.row0.setText(world[0][0]+world[0][1]+world[0][2]+world[0][3]+world[0][4]+world[0][5]+world[0][6]+world[0][7]+world[0][8]+world[0][9]+world[0][10]+world[0][11]+world[0][12]+world[0][13]+world[0][14]+world[0][15]+world[0][16]+world[0][17]+world[0][18]+world[0][19]+"XP: "+Frame.xp);
		Frame.row1.setText(world[1][0]+world[1][1]+world[1][2]+world[1][3]+world[1][4]+world[1][5]+world[1][6]+world[1][7]+world[1][8]+world[1][9]+world[1][10]+world[1][11]+world[1][12]+world[1][13]+world[1][14]+world[1][15]+world[1][16]+world[1][17]+world[1][18]+world[1][19]+"LVL: "+Frame.lvl);
		Frame.row2.setText(world[2][0]+world[2][1]+world[2][2]+world[2][3]+world[2][4]+world[2][5]+world[2][6]+world[2][7]+world[2][8]+world[2][9]+world[2][10]+world[2][11]+world[2][12]+world[2][13]+world[2][14]+world[2][15]+world[2][16]+world[2][17]+world[2][18]+world[2][19]+"GOLD: "+Frame.gold);
		Frame.row3.setText(world[3][0]+world[3][1]+world[3][2]+world[3][3]+world[3][4]+world[3][5]+world[3][6]+world[3][7]+world[3][8]+world[3][9]+world[3][10]+world[3][11]+world[3][12]+world[3][13]+world[3][14]+world[3][15]+world[2][16]+world[2][17]+world[2][18]+world[2][19]);
		y++;
		Frame.row4.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]+"Tool: "+Frame.block);
		y++;
		Frame.row5.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]+"Wood: "+Frame.wood);
		y++;
		Frame.row6.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]+"Soil: "+Frame.dirt);
		y++;
		Frame.row7.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]+"Stone: "+Frame.stone);
		y++;
		Frame.row8.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row9.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row10.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row11.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row12.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row13.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row14.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row15.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row16.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row17.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row18.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		y++;
		Frame.row19.setText(world[y][0]+world[y][1]+world[y][2]+world[y][3]+world[y][4]+world[y][5]+world[y][6]+world[y][7]+world[y][8]+world[y][9]+world[y][10]+world[y][11]+world[y][12]+world[y][13]+world[y][14]+world[y][15]+world[y][16]+world[y][17]+world[y][18]+world[y][19]);
		} catch (Exception e) {
			
		}
	}
	
	public static void clearWorld() {
		for (int i = 0; i < 20;i++) {
			for (int j = 0;j < 20 ; j++) {
				world[i][j] = ".";
			}
		}
	}
	
	public static void clearMap(int[][] map) {
		for (int i = 0; i < 19;i++) {
			for (int j = 0;j < 19 ; j++) {
				map[i][j] = 0;
			}
		}
	}
	
	static musicStuff music = new musicStuff();
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		//music.playMusic("res/Dynasty_Main_Theme.wav");
		frame.FrameInit(500, 480, "Menlo", 20);
		printWorld();
		frame.AnnouncementsInit(500, 250, "Menlo", 20);
		MagicGen.Gen();
		for (int i = 0; i < 500; i++) {
			LevelGen.gen(500, 5);
		}
		for (int j = 0; j < 5; j++) {
			LevelGen.genEnemies();
		}
		Personality.personalityMenu();
		for (int n = 0; n <20; n++) {
			for (int m = 0; m <20; m++) {
				if (m == 0 || n == 0 || m == 19 || n == 19) {
					if(world[n][m] == "Ω") {
						world[n][m] = ".";
					}
				}
			}
		}
		Frame.setAnnouncement(Color.YELLOW, "Welcome to Dynasty II!");
		Frame.block = "shovel";
		printWorld();
		}
	
	public static void Reader(int line , String filePath) throws FileNotFoundException {
		File dialog = new File(filePath);
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(dialog);
		for (int i = 0; i < line ; i++)
			out = scan.nextLine();
	}
	public static void pause(int ms) {
	    try {
	        Thread.sleep(ms);
	    } catch (InterruptedException e) {
	        System.err.format("IOException: %s%n", e);
	    }
	}
}
