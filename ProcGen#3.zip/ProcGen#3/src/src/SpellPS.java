package src;

public class SpellPS {
	
	//Fire Properties
	public static boolean touchFire = false;
	public static boolean ballFire = false;
	public static boolean summonFire = false;
	
	//Water Properties
	public static boolean extinguish = false;
	public static boolean ballWater = false;
	public static boolean summonWater = false;
	
	//Air Properties
	public static boolean blowDown = false;
	public static boolean summonWind = false;
	
	//Usage Properties
	public static boolean singleUse = false;
	public static boolean oncePerDay = false;
	public static boolean tenPerDay = false;
	public static boolean infiniteUse = false;
	
	//Damage Properties
	public static boolean damagesSelf = false;
	public static boolean damagesEnemies = false;
	public static boolean splashDamage = false;
	public static boolean coneDamage = false;
}
