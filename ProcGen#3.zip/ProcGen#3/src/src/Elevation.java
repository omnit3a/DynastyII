package src;

public class Elevation {
	
	public static void ElevationMap() {
		for (int i = 0 ; i < 20 ; i++) {
			for (int j = 0 ; j < 20 ; j++) {
				if (Main.world[i][j] == "▒") {
					Main.worldElevationMap[i][j] = Main.worldElevationMap[i][j] + 1;
				}
			}
		}
	}
}
