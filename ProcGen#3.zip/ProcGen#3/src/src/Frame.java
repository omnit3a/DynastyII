package src;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class Frame{
	public static Random r = new Random();
	public static JLabel row0 = new  JLabel();
	public static JLabel row1 = new  JLabel();
	public static JLabel row2 = new  JLabel();
	public static JLabel row3 = new  JLabel();
	public static JLabel row4 = new  JLabel();
	public static JLabel row5 = new  JLabel();
	public static JLabel row6 = new  JLabel();
	public static JLabel row7 = new  JLabel();
	public static JLabel row8 = new  JLabel();
	public static JLabel row9 = new  JLabel();
	public static JLabel row10 = new  JLabel();
	public static JLabel row11 = new  JLabel();
	public static JLabel row12 = new  JLabel();
	public static JLabel row13 = new  JLabel();
	public static JLabel row14 = new  JLabel();
	public static JLabel row15 = new  JLabel();
	public static JLabel row16 = new  JLabel();
	public static JLabel row17 = new  JLabel();
	public static JLabel row18 = new  JLabel();
	public static JLabel row19 = new  JLabel();
	public static int x = 0;
	public static int y = 0;
	public static JFrame frame = new JFrame("Dynasty");
	public static JPanel panel = new JPanel();
	public static JFrame frameA = new JFrame("Announcements");
	public static JPanel panelA = new JPanel();
	public static JLabel row0A = new  JLabel();
	public static JLabel row1A = new  JLabel();
	public static JLabel row2A = new  JLabel();
	public static JLabel row3A = new  JLabel();
	public static JLabel row4A = new  JLabel();
	public static String nonsolids = ".~";
	public static String solids = "@▒";
	
	public static int absX;
	public static int absY;
	public static int seed1;
	public static int seed2;
	
	static String enemy = null;
	static boolean inCombat;
	
	public static String dir;
	
	public static boolean killedTroll;
	public static String block = "";
	
	public static int xp = 0;
	public static int lvl = 0;
	public static double reqLevel = 10;
	public static int gold = 0;
	public static int wood = 0;
	public static int dirt = 0;
	public static int stone = 0;
	
	public static int turn = 0;
	
	public static int phobialevel;
	
	public static Long seed = r.nextLong();
	public static void FrameInit(int width, int height, String fontIn, int size) {
		
		Font font = new Font(fontIn, Font.BOLD, size);
		
		
		frame.setSize(width,height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocation(800, 0);
		frame.add(panel);
		row0.setFont(font);
		row1.setFont(font);
		row2.setFont(font);
		row3.setFont(font);
		row4.setFont(font);
		row5.setFont(font);
		row6.setFont(font);
		row7.setFont(font);
		row8.setFont(font);
		row9.setFont(font);
		row10.setFont(font);
		row11.setFont(font);
		row12.setFont(font);
		row13.setFont(font);
		row14.setFont(font);
		row15.setFont(font);
		row16.setFont(font);
		row17.setFont(font);
		row18.setFont(font);
		row19.setFont(font);
		panel.setLayout(new GridLayout(0,1));
		row0.setForeground(Color.WHITE);
		row1.setForeground(Color.WHITE);
		row2.setForeground(Color.WHITE);
		row3.setForeground(Color.WHITE);
		row4.setForeground(Color.WHITE);
		row5.setForeground(Color.WHITE);
		row6.setForeground(Color.WHITE);
		row7.setForeground(Color.WHITE);
		row8.setForeground(Color.WHITE);
		row9.setForeground(Color.WHITE);
		row10.setForeground(Color.WHITE);
		row11.setForeground(Color.WHITE);
		row12.setForeground(Color.WHITE);
		row13.setForeground(Color.WHITE);
		row14.setForeground(Color.WHITE);
		row15.setForeground(Color.WHITE);
		row16.setForeground(Color.WHITE);
		row17.setForeground(Color.WHITE);
		row18.setForeground(Color.WHITE);
		row19.setForeground(Color.WHITE);
		panel.add(row0);
		panel.add(row1);
		panel.add(row2);
		panel.add(row3);
		panel.add(row4);
		panel.add(row5);
		panel.add(row6);
		panel.add(row7);
		panel.add(row8);
		panel.add(row9);
		panel.add(row10);
		panel.add(row11);
		panel.add(row12);
		panel.add(row13);
		panel.add(row14);
		panel.add(row15);
		panel.add(row16);
		panel.add(row17);
		panel.add(row18);
		panel.add(row19);
		panel.setBackground(Color.BLACK);
		panel.setVisible(true);
		panel.setSize(width,height);
		panel.setLocation(512,480);
		frame.setVisible(true);
		frame.setResizable(false);
	}
	public static void AnnouncementsInit(int width, int height, String fontIn, int size) {
		
		Font font = new Font(fontIn, Font.BOLD, size);
		
		frameA.setSize(width,height);
		frameA.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameA.setLocation(800, 505);
		frameA.add(panelA);
		frameA.setResizable(false);
		row0A.setFont(font);
		row1A.setFont(font);
		row2A.setFont(font);
		row3A.setFont(font);
		row4A.setFont(font);
		panelA.setLayout(new GridLayout(0,1));
		panelA.setBackground(Color.BLACK);
		row0A.setForeground(Color.WHITE);
		row1A.setForeground(Color.WHITE);
		row2A.setForeground(Color.GREEN);
		row3A.setForeground(Color.WHITE);
		row4A.setForeground(Color.BLUE);
		panelA.add(row0A);
		panelA.add(row1A);
		panelA.add(row2A);
		panelA.add(row3A);
		panelA.add(row4A);
		panelA.setVisible(true);
		panel.setSize(width,height);
		panel.setLocation(800, 400);
		frameA.setVisible(true);
		row1A.setText("(A)ttack | (S)earch | (R)est | (M)editate"); //Announcemnts menu
		row1A.setForeground(Color.WHITE); //Announcemnts menu
		row2A.setText("(Up) | (Down) | (Left) | (Right)"); //Announcemnts menu
		row3A.setText("(L)evel Up | (B)uild/Break"); //Announcemnts menu
		frameA.addKeyListener(new KeyListener() { //Announcemnts menu

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				int keyCode = e.getKeyCode();
				
				switch (keyCode) {
					case KeyEvent.VK_A:
						if (enemy == "TROLL") {
							inCombat = true;
							int bodyPart = r.nextInt(11);
							if (BodyParts.HeadT > 0) {
							switch (bodyPart) {
								case 1:
									int damage = r.nextInt(20+lvl);
									if (BodyParts.LeftArmT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.LeftArmH > 0 && BodyParts.HeadH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.LeftArmT -= damage;
										if (BodyParts.LeftArmT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's left arm");
											BodyParts.LeftArmT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.LeftArmH -= damage;
										if (BodyParts.LeftArmH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your left arm was destroyed");
											BodyParts.LeftArmH = 0;
											break;
											}
										}
									break;
									} else {
										break;
									}
								case 2:
									damage = r.nextInt(20+lvl);
									if (BodyParts.RightArmT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.RightArmH > 0 && BodyParts.HeadH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.RightArmT -= damage;
										if (BodyParts.RightArmT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's right arm");
											BodyParts.RightArmT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.RightArmH -= damage;
										if (BodyParts.RightArmH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your right arm was destroyed");
											BodyParts.RightArmH = 0;
											break;
											}
										break;
										}
									} else {
										break;
									}
								case 3:
									damage = r.nextInt(20+lvl);
									if (BodyParts.LeftHandT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.LeftHandH > 0 && BodyParts.HeadH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.LeftHandT -= damage;
										if (BodyParts.LeftHandT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's left hand");
											BodyParts.LeftHandT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.RightArmH -= damage;
										if (BodyParts.RightArmH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your left hand was destroyed");
											BodyParts.RightArmH = 0;
											break;
											}
										break;
										}
									} else {
										break;
									}
								case 4:
									damage = r.nextInt(20+lvl);
									if (BodyParts.RightHandT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0 && BodyParts.RightHandH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.RightHandT -= damage;
										if (BodyParts.RightHandT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's right hand");
											BodyParts.RightHandT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.RightHandH -= damage;
										if (BodyParts.RightHandH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your right hand was destroyed");
											BodyParts.RightHandH = 0;
											break;
											}
										break;
										}
									} else {
										break;
									}
								case 5:
									damage = r.nextInt(20+lvl);
									if (BodyParts.LeftLegT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0  && BodyParts.LeftLegH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.LeftLegT -= damage;
										if (BodyParts.LeftLegT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's left leg");
											BodyParts.LeftLegT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.LeftLegH -= damage;
										if (BodyParts.LeftLegH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your left leg was destroyed");
											BodyParts.RightHandH = 0;
											break;
											}
										break;
										}
									} else {
										break;
									}
								case 6:
									damage = r.nextInt(20+lvl);
									if (BodyParts.RightLegT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0 && BodyParts.RightLegH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.RightLegT -= damage;
										if (BodyParts.RightLegT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's right leg");
											BodyParts.RightLegT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.RightLegH -= damage;
										if (BodyParts.RightLegH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your right leg was destroyed");
											BodyParts.RightLegH = 0;
											break;
											}
										}
									break;
									} else {
										break;
									}
								case 7:
									damage = r.nextInt(20+lvl);
									if (BodyParts.UpperTorsoT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0 && BodyParts.UpperTorsoH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.UpperTorsoT -= damage;
										if (BodyParts.UpperTorsoT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's upper torso");
											BodyParts.UpperTorsoT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.UpperTorsoH -= damage;
										if (BodyParts.UpperTorsoH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your upper torso was destroyed");
											BodyParts.UpperTorsoH = 0;
											break;
											}
										}
									break;
									} else {
										break;
									}
								case 8:
									damage = r.nextInt(20+lvl);
									if (BodyParts.LowerTorsoT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.LowerTorsoT -= damage;
										if (BodyParts.LowerTorsoT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's lower torso");
											BodyParts.LowerTorsoT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.LowerTorsoH -= damage;
										if (BodyParts.LowerTorsoH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your lower torso was destroyed");
											BodyParts.LowerTorsoH = 0;
											BodyParts.InfectionTurnH = turn;
											BodyParts.InfectedH = true;
											break;
											}
										}
									break;
									} else {
										break;
									}
								case 9:
									damage = r.nextInt(20+lvl);
									if (BodyParts.NeckT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0  && BodyParts.NeckH > 00) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.NeckT -= damage;
										if (BodyParts.NeckT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's neck");
											BodyParts.NeckT = 0;
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.NeckH -= damage;
										if (BodyParts.NeckH <= BodyParts.acH*3) {
											setAnnouncement(Color.RED, "Your neck was destroyed");
											BodyParts.NeckH = 0;
											break;
											}
										}
									break;
									} else {
										break;
									}
								case 10:
									damage = r.nextInt(20+lvl);
									if (BodyParts.HeadT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.HeadT -= damage;
										if (BodyParts.HeadT <= BodyParts.acT*3) {
											gold += r.nextInt(20);
											setAnnouncement(Color.GREEN, "You kill the Troll");
											Personality.personalityMenu();
											enemy = null;
											BodyParts.HeadT = 0;
											xp += 2;
											try {
											switch(dir) {
												case "UP":
													Main.world[y-1][x] = "~";
													Main.worldLiquidConcentration[y-1][x] = Main.worldLiquidConcentration[y-1][x] + 1;
													Main.printWorld();
													BodyParts.acT = 6;
													BodyParts.LeftArmT = 100;
													BodyParts.RightArmT = 100;
													BodyParts.LeftHandT = 100;
													BodyParts.RightHandT = 100;
													BodyParts.LeftLegT = 100;
													BodyParts.RightLegT = 100;
													BodyParts.UpperTorsoT= 100;
													BodyParts.LowerTorsoT = 100;
													BodyParts.NeckT = 100;
													BodyParts.HeadT = 100;
													BodyParts.TailT = 100;
													break;
												case "DOWN":
													Main.world[y+1][x] = "~";
													Main.worldLiquidConcentration[y+1][x] = Main.worldLiquidConcentration[y+1][x] + 1;
													Main.printWorld();
													BodyParts.acT = 6;
													BodyParts.LeftArmT = 100;
													BodyParts.RightArmT = 100;
													BodyParts.LeftHandT = 100;
													BodyParts.RightHandT = 100;
													BodyParts.LeftLegT = 100;
													BodyParts.RightLegT = 100;
													BodyParts.UpperTorsoT= 100;
													BodyParts.LowerTorsoT = 100;
													BodyParts.NeckT = 100;
													BodyParts.HeadT = 100;
													BodyParts.TailT = 100;
													break;
												case "LEFT":
													Main.world[y][x-1] = "~";
													Main.worldLiquidConcentration[y][x-1] = Main.worldLiquidConcentration[y][x-1] + 1;
													Main.printWorld();
													BodyParts.acT = 6;
													BodyParts.LeftArmT = 100;
													BodyParts.RightArmT = 100;
													BodyParts.LeftHandT = 100;
													BodyParts.RightHandT = 100;
													BodyParts.LeftLegT = 100;
													BodyParts.RightLegT = 100;
													BodyParts.UpperTorsoT= 100;
													BodyParts.LowerTorsoT = 100;
													BodyParts.NeckT = 100;
													BodyParts.HeadT = 100;
													BodyParts.TailT = 100;
													break;
												case "RIGHT":
													Main.world[y][x+1] = "~";
													Main.worldLiquidConcentration[y][x+1] = Main.worldLiquidConcentration[y][x+1] + 1;
													Main.printWorld();
													BodyParts.acT = 6;
													BodyParts.LeftArmT = 100;
													BodyParts.RightArmT = 100;
													BodyParts.LeftHandT = 100;
													BodyParts.RightHandT = 100;
													BodyParts.LeftLegT = 100;
													BodyParts.RightLegT = 100;
													BodyParts.UpperTorsoT= 100;
													BodyParts.LowerTorsoT = 100;
													BodyParts.NeckT = 100;
													BodyParts.HeadT = 100;
													BodyParts.TailT = 100;
													break;
											}
											} catch (ArrayIndexOutOfBoundsException e3) {
												
											}
											break;
										}
										break;
									} else {
										damage = r.nextInt(20);
										BodyParts.HeadH -= damage;
										if (BodyParts.HeadH <= BodyParts.acH*2) {
											setAnnouncement(Color.RED, "You were killed");
											BodyParts.HeadH = 100;
											x = 0;
											y = 0;
											BodyParts.acT = 6;
											BodyParts.LeftArmT = 100;
											BodyParts.RightArmT = 100;
											BodyParts.LeftHandT = 100;
											BodyParts.RightHandT = 100;
											BodyParts.LeftLegT = 100;
											BodyParts.RightLegT = 100;
											BodyParts.UpperTorsoT= 100;
											BodyParts.LowerTorsoT = 100;
											BodyParts.NeckT = 100;
											BodyParts.HeadT = 100;
											BodyParts.TailT = 100;
											lvl = 0;
											xp = 0;
											gold = 0;
											wood = 0;
											BodyParts.InfectionTurnH = 0;
											BodyParts.InfectedH = false;
											Main.clearWorld();
											for (int i = 0; i < 500; i++) {
												LevelGen.gen(500, 5);
											}
											for (int j = 0; j < 5; j++) {
												LevelGen.genEnemies();
											}
											for (int n = 0; n <20; n++) {
												for (int m = 0; m <20; m++) {
													if (m == 0 || n == 0 || m == 19 || n == 19) {
														if(Main.world[n][m] == "Ω") {
															Main.world[n][m] = ".";
														}
													}
												}
											}
											for (int i = 0; i < Personality.phobias.length; i++) {
												Personality.phobias[i] = "";
											}
											Personality.motivation = 100;
											Personality.depressed = false;
											Personality.generalHappiness = 112;
											Personality.personalityMenu();
											Personality.setMentality(Color.BLUE, "General Happiness: "+Personality.generalHappiness);
											MagicGen.Gen();
											enemy = null;
											Main.printWorld();
											break;
											}
										}
									break;
									} else {
										break;
									}
								case 11:
									damage = r.nextInt(20+lvl);
									if (BodyParts.TailT >= BodyParts.acT*3 && (BodyParts.LeftArmH > 0 || BodyParts.RightArmH > 0 || BodyParts.LeftHandH > 0 || BodyParts.RightHandH > 0 ) && BodyParts.HeadH > 0) {
									if (damage > BodyParts.acT) {
										setAnnouncement(Color.GREEN, "Damage: "+damage);
										BodyParts.TailT -= damage;
										if (BodyParts.TailT <= BodyParts.acT*3) {
											setAnnouncement(Color.MAGENTA, "You destroy the Troll's tail");
											BodyParts.TailT = 0;
											break;
										}
									}
									break;
									}
									break;
								}
							break;
							}
						}
						break;
					case KeyEvent.VK_S:
						try {
						switch (enemy) {
							case "BLOOD":
								setAnnouncement(Color.RED, "It's a congealed pool of blood");
								enemy = null;
								break;
							case "SKELETON":
								setAnnouncement(Color.WHITE, "It's an gathering of Bones");
								break;
							case "TROLL":
								setAnnouncement(Color.WHITE, "It's an eyeless beast");
								break;
							case "WALL":
								setAnnouncement(Color.WHITE, "It's a rough stone wall");
								enemy = null;
								break;
							case "GROUND":
								setAnnouncement(Color.RED, "Nothing to search");
								break;
							default:
								setAnnouncement(Color.RED, "Nothing to search");
								break;
						}
						} catch (Exception e4) {
							
						}
						break;
					case KeyEvent.VK_Z:
						switch (dir) {
							case"UP":
								if (Main.world[y-1][x] == "▒") {
									Main.clearWorld();
									y--;
									for (int i = 0; i < 500; i++) {
										LevelGen.genUpper(500, 5);
									}
									MagicGen.Gen();
									Main.printWorld();
								}
									break;
							case"DOWN":
								if (Main.world[y+1][x] == "▒") {
									Main.clearWorld();
									y++;
									for (int i = 0; i < 500; i++) {
										LevelGen.genUpper(500, 5);
									}
									MagicGen.Gen();
									Main.printWorld();
								}
									break;
							case"LEFT":
								if (Main.world[y][x-1] == "▒") {
									Main.clearWorld();
									x--;
									for (int i = 0; i < 500; i++) {
										LevelGen.genUpper(500, 5);
									}
									MagicGen.Gen();
									Main.printWorld();
								}
									break;
							case"RIGHT":
								if (Main.world[y][x+1] == "▒") {
									Main.clearWorld();
									x++;
									for (int i = 0; i < 500; i++) {
										LevelGen.genUpper(500, 5);
									}
									MagicGen.Gen();
									Main.printWorld();
								}
									break;
						}
						break;
					case KeyEvent.VK_X:
						switch (dir) {
						case"UP":
							if (Main.world[y-1][x] == " ") {
								Main.clearWorld();
								y--;
								LevelGen.genLower();
								Main.printWorld();
								
							}
								break;
						case"DOWN":
							if (Main.world[y+1][x] == " ") {
								Main.clearWorld();
								y++;
								LevelGen.genLower();
								Main.printWorld();
							}
								break;
						case"LEFT":
							if (Main.world[y][x-1] == " ") {
								Main.clearWorld();
								x--;
								LevelGen.genLower();
								Main.printWorld();
							}
								break;
						case"RIGHT":
							if (Main.world[y][x+1] == " ") {
								Main.clearWorld();
								x++;
								LevelGen.genLower();
								Main.printWorld();
							}
								break;
					}
					break;
					case KeyEvent.VK_R:
						int takesFrost = r.nextInt(4);
						if (enemy == null && takesFrost != 1) {
							setAnnouncement(Color.GREEN, "You succesfully recover");
							BodyParts.acH = 12;
							BodyParts.LeftArmH = 100;
							BodyParts.RightArmH = 100;
							BodyParts.LeftHandH = 100;
							BodyParts.RightHandH = 100;
							BodyParts.LeftLegH = 100;
							BodyParts.RightLegH = 100;
							BodyParts.UpperTorsoH= 100;
							BodyParts.LowerTorsoH = 100;
							BodyParts.NeckH = 100;
							BodyParts.HeadH = 100;
							BodyParts.LeftEyeH = 100;
							BodyParts.RightEyeH = 100;
							Personality.personalityMenu();
							enemy = "SLEPT";
						} else if (takesFrost == 1 && enemy == null) {
							int damage = r.nextInt(20);
							enemy = "SLEPT";
							setAnnouncement(Color.CYAN, "You sleep in the cold. "+"-"+damage);
							BodyParts.HeadH -= damage;
							Personality.personalityMenu();
						} else {
							setAnnouncement(Color.RED, "You aren't tired enough to sleep");
						}
						
						break;
					case KeyEvent.VK_M:
						if (enemy == null && Personality.generalHappiness < 90 && Personality.generalHappiness > 70) {
							setAnnouncement(Color.GREEN, "You meditate");
							Personality.motivation += 10;
							BodyParts.HeadH = 100;
							Personality.personalityMenu();
						} else {
							setAnnouncement(Color.RED, "You can't clear your head");
						}
						break;
					case KeyEvent.VK_L:
						if (xp >= reqLevel) {
							xp = 0;
							lvl++;
							reqLevel = (lvl*lvl);
						}
						break;
					case KeyEvent.VK_Y:
						dir = "UP";
						break;
					case KeyEvent.VK_H:
						dir = "DOWN";
						break;
					case KeyEvent.VK_G:
						dir = "LEFT";
						break;
					case KeyEvent.VK_J:
						dir = "RIGHT";
						break;
					case KeyEvent.VK_1:
						block = "wood";
						Main.printWorld();
						break;
					case KeyEvent.VK_2:
						block = "shovel";
						Main.printWorld();
						break;
					case KeyEvent.VK_3:
						block = "stone";
						Main.printWorld();
						break;
					case KeyEvent.VK_B:
						Builder.BuildScript();
						break;
					case KeyEvent.VK_UP:
						dir = "UP";
						if (y != 0 && Main.world[y-1][x] == ".") {
							turn++;
							y--;
							Main.world[y][x] = "@";
							Main.world[y+1][x] = ".";
							setAnnouncement(Color.WHITE, "You go North");
							Main.printWorld();
							dir = "UP";
						} else if (y == 0) {
							Main.clearMap(Main.worldElevationMap);
							turn++;
							dir = "UP";
							y = 19;
							Main.clearWorld();
							for (int i = 0; i < 500; i++) {
								LevelGen.gen(500, 5);
							}
							for (int j = 0; j < 5; j++) {
								LevelGen.genEnemies();
							}
							MagicGen.Gen();
							Main.printWorld();
						}
						try {
							switch (Main.world[y-1][x]) {
							case "Ω":
								dir = "UP";
								setAnnouncement(Color.MAGENTA, "You see a troll");
								enemy = "TROLL";
								break;
							case "S":
								dir = "UP";
								setAnnouncement(Color.MAGENTA, "You see a skelelton");
								enemy = "SKELETON";
								break;
							case "~":
								dir = "UP";
								setAnnouncement(Color.MAGENTA, "You see Blood");
								enemy = "BLOOD";
								break;
							case "▒":
								dir = "UP";
								setAnnouncement(Color.MAGENTA, "You see a Wall");
								enemy = "WALL";
								break;
							}
						} catch (Exception e2) {
							
						}
						if (BodyParts.InfectedH == true && turn == BodyParts.InfectionTurnH + 100) {
							BodyParts.die("You died via infection");
						}
						break;
					case KeyEvent.VK_DOWN:
						dir = "DOWN";
						if (y != 19 && Main.world[y+1][x] == ".") {
							turn++;
							y++;
							Main.world[y][x] = "@";
							Main.world[y-1][x] = ".";
							setAnnouncement(Color.WHITE, "You go South");
							Main.printWorld();
							dir = "DOWN";
						} else if (y == 19) {
							Main.clearMap(Main.worldElevationMap);
							turn++;
							dir = "DOWN";
							y = 0;
							Main.clearWorld();
							for (int i = 0; i < 500; i++) {
								LevelGen.gen(500, 5);
							}
							for (int j = 0; j < 5; j++) {
								LevelGen.genEnemies();
							}
							MagicGen.Gen();
							Main.printWorld();
						}
						try {
							switch (Main.world[y+1][x]) {
								case "Ω":
									dir = "DOWN";
									setAnnouncement(Color.MAGENTA, "You see a troll");
									enemy = "TROLL";
									break;
								case "S":
									dir = "DOWN";
									setAnnouncement(Color.MAGENTA, "You see a skelelton");
									enemy = "SKELETON";
									break;
								case "~":
									dir = "DOWN";
									setAnnouncement(Color.MAGENTA, "You see blood");
									enemy = "BLOOD";
									break;
								case "▒":
									dir = "DOWN";
									setAnnouncement(Color.MAGENTA, "You see a Wall");
									enemy = "WALL";
									break;
							}
						} catch (Exception e2) {
							
						}
						if (BodyParts.InfectedH == true && turn == BodyParts.InfectionTurnH + 100) {
							BodyParts.die("You died via infection");
						}
						break;
					case KeyEvent.VK_LEFT:
						dir = "LEFT";
						if (x != 0 && Main.world[y][x-1] == ".") {
							turn++;
							x--;
							Main.world[y][x] = "@";
							Main.world[y][x+1] = ".";
							setAnnouncement(Color.WHITE, "You go Left");
							Main.printWorld();
							dir = "LEFT";
						} else if (x == 0) {
							Main.clearMap(Main.worldElevationMap);
							turn++;
							x = 19;
							Main.clearWorld();
							for (int i = 0; i < 500; i++) {
								LevelGen.gen(500, 5);
							}
							for (int j = 0; j < 5; j++) {
								LevelGen.genEnemies();
							}
							MagicGen.Gen();
							Main.printWorld();
						}
						try {
							switch (Main.world[y][x-1]) {
							case "Ω":
								dir = "LEFT";
								setAnnouncement(Color.MAGENTA, "You see a troll");
								enemy = "TROLL";
								break;
							case "S":
								dir = "UP";
								setAnnouncement(Color.MAGENTA, "You see a skelelton");
								enemy = "SKELETON";
								break;
							case "~":
								dir = "LEFT";
								setAnnouncement(Color.MAGENTA, "You see blood");
								enemy = "BLOOD";
								break;
							case "▒":
								dir = "LEFT";
								setAnnouncement(Color.MAGENTA, "You see a Wall");
								enemy = "WALL";
								break;
							}
						} catch (Exception e2) {
							
						}
						if (BodyParts.InfectedH == true && turn == BodyParts.InfectionTurnH + 100) {
							BodyParts.die("You died via infection");
						}
						break;
					case KeyEvent.VK_RIGHT:
						dir = "RIGHT";
						if (x != 19 && Main.world[y][x+1] == ".") {
							turn++;
							x++;
							Main.world[y][x] = "@";
							Main.world[y][x-1] = ".";
							setAnnouncement(Color.WHITE, "You go Right");
							Main.printWorld();
							dir = "RIGHT";
						} else if (x == 19) {
							Main.clearMap(Main.worldElevationMap);
							turn++;
							x = 0;
							Main.clearWorld();
							for (int i = 0; i < 500; i++) {
								LevelGen.gen(500, 5);
							}
							for (int j = 0; j < 5; j++) {
								LevelGen.genEnemies();
							}
							MagicGen.Gen();
							Main.printWorld();
						}
						try {
							switch (Main.world[y][x+1]) {
							case "Ω":
								dir = "RIGHT";
								setAnnouncement(Color.MAGENTA, "You see a troll");
								enemy = "TROLL";
								break;
							case "S":
								dir = "UP";
								setAnnouncement(Color.MAGENTA, "You see a skelelton");
								enemy = "SKELETON";
								break;
							case "~":
								dir = "RIGHT";
								setAnnouncement(Color.MAGENTA, "You see blood");
								enemy = "BLOOD";
								break;
							case "▒":
								dir = "RIGHT";
								setAnnouncement(Color.MAGENTA, "You see a Wall");
								enemy = "WALL";
								break;
							}
						} catch (Exception e2) {
							
						}
						if (BodyParts.InfectedH == true && turn == BodyParts.InfectionTurnH + 100) {
							BodyParts.die("You died via infection");
						}
						break;
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
	}
	
	public static void setAnnouncement(Color color, String text) {
		row0A.setForeground(color);
		row0A.setText(text);
	}
}

