package src;

import java.awt.Color;

public class BodyParts {
	
	//Human
	public static int acH = 12;
	public static int LeftArmH = 100;
	public static int RightArmH = 100;
	public static int LeftHandH = 100;
	public static int RightHandH = 100;
	public static int LeftLegH = 100;
	public static int RightLegH = 100;
	public static int UpperTorsoH= 100;
	public static int LowerTorsoH = 100;
	public static int NeckH = 100;
	public static int HeadH = 100;
	public static int LeftEyeH = 100;
	public static int RightEyeH = 100;
	public static int InfectionTurnH = 0;
	public static boolean InfectedH = false;
	
	//Troll
	public static int acT = 6;
	public static int LeftArmT = 100;
	public static int RightArmT = 100;
	public static int LeftHandT = 100;
	public static int RightHandT = 100;
	public static int LeftLegT = 100;
	public static int RightLegT = 100;
	public static int UpperTorsoT= 100;
	public static int LowerTorsoT = 100;
	public static int NeckT = 100;
	public static int HeadT = 100;
	public static int TailT = 100;
	
	//Skeleton
	public static int acS = 6;
	public static int LeftArmS = 100;
	public static int RightArmS = 100;
	public static int LeftHandS = 100;
	public static int RightHandS = 100;
	public static int LeftLegS = 100;
	public static int RightLegS = 100;
	public static int UpperTorsoS = 100;
	public static int LowerTorsoS = 100;
	public static int NeckS = 100;
	public static int HeadS = 100;
	
	//Ant
	public static int acA = 2;
	public static int MandiblesA = 100;
	public static int AbdomenA = 100;
	public static int ThoraxA = 100;
	public static int LeftLegsA = 100;
	public static int RightLegsA = 100;
	
	public static void die(String text) {
		Main.clearMap(Main.worldElevationMap);
		Frame.setAnnouncement(Color.RED, text);
		BodyParts.HeadH = 100;
		Frame.x = 0;
		Frame.y = 0;
		BodyParts.acT = 6;
		BodyParts.LeftArmT = 100;
		BodyParts.RightArmT = 100;
		BodyParts.LeftHandT = 100;
		BodyParts.RightHandT = 100;
		BodyParts.LeftLegT = 100;
		BodyParts.RightLegT = 100;
		BodyParts.UpperTorsoT= 100;
		BodyParts.LowerTorsoT = 100;
		BodyParts.NeckT = 100;
		BodyParts.HeadT = 100;
		BodyParts.TailT = 100;
		Frame.lvl = 0;
		Frame.xp = 0;
		Frame.gold = 0;
		Frame.wood = 0;
		BodyParts.InfectionTurnH = 0;
		BodyParts.InfectedH = false;
		Main.clearWorld();
		for (int i = 0; i < 500; i++) {
			LevelGen.gen(500, 5);
		}
		for (int j = 0; j < 5; j++) {
			LevelGen.genEnemies();
		}
		for (int n = 0; n <20; n++) {
			for (int m = 0; m <20; m++) {
				if (m == 0 || n == 0 || m == 19 || n == 19) {
					if(Main.world[n][m] == "Ω") {
						Main.world[n][m] = ".";
					}
				}
			}
		}
		for (int i = 0; i < Personality.phobias.length; i++) {
			Personality.phobias[i] = "";
		}
		Personality.motivation = 100;
		Personality.depressed = false;
		Personality.generalHappiness = 112;
		Personality.personalityMenu();
		Personality.setMentality(Color.BLUE, "General Happiness: "+Personality.generalHappiness);
		MagicGen.Gen();
		Frame.enemy = null;
		Main.printWorld();
	}
}
