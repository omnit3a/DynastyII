package src;

import java.awt.Color;
import java.util.Random;

public class MagicGen {
	static Random r = new Random();
	public static boolean hasFireSpell;
	public static boolean hasWaterSpell;
	public static boolean hasAirSpell;
	public static int whichSpellType;
	public static int whichSpell;
	public static int whichUsage;
	public static int whichDamage;
	public static boolean[][] spell = {
			{false,false,false},
			{false,false,false},
			{false,false},
			{false,false,false,false},
			{false,false,false,false}
	};
	
	public static String a = "";
	public static String b = "";
	public static String c = "";
	public static String d = "";
	public static String e = "";
	public static void Gen() {
				spell[0][0] = false;
				spell[0][1] = false;
				spell[0][2] = false;
				spell[1][0] = false;
				spell[1][1] = false;
				spell[1][2] = false;
				spell[2][0] = false;
				spell[2][1] = false;
				spell[3][0] = false;
				spell[3][1] = false;
				spell[3][2] = false;
				spell[3][3] = false;
				spell[4][0] = false;
				spell[4][1] = false;
				spell[4][2] = false;
				spell[4][3] = false;
		whichSpellType = r.nextInt(3);
		switch (whichSpellType) {
			case 1:
				hasFireSpell = true;
				whichSpell = r.nextInt(3);
				switch(whichSpell) {
					case 1:
						SpellPS.touchFire = true;
						spell[0][0] = true;
						break;
					case 2:
						SpellPS.ballFire = true;
						spell[0][1] = true;
						break;
					case 3:
						SpellPS.summonFire = true;
						spell[0][2] = true;
						break;
				}
				whichUsage = r.nextInt(4);
				switch(whichUsage) {
					case 0:
						SpellPS.singleUse = true;
						spell[3][0] = true;
						break;
					case 1:
						SpellPS.oncePerDay = true;
						spell[3][1] = true;
						break;
					case 2:
						SpellPS.tenPerDay = true;
						spell[3][2] = true;
						break;
					case 3:
						SpellPS.infiniteUse = true;
						spell[3][3] = true;
						break;	
				}
				whichDamage = r.nextInt(4);
				switch(whichDamage) {
					case 0:
						SpellPS.damagesSelf= true;
						spell[4][0] = true;
						break;
					case 1:
						SpellPS.damagesEnemies = true;
						spell[4][1] = true;
						break;
					case 2:
						SpellPS.coneDamage = true;
						spell[4][2] = true;
						break;
					case 3:
						SpellPS.splashDamage = true;
						spell[4][3] = true;
						break;	
				}
				break;
			case 2:
				hasWaterSpell = true;
				whichSpell = r.nextInt(3);
				switch(whichSpell) {
					case 1:
						SpellPS.extinguish = true;
						spell[1][0] = true;
						break;
					case 2:
						SpellPS.ballWater = true;
						spell[1][1] = true;
						break;
					case 3:
						SpellPS.summonWater = true;
						spell[1][2] = true;
						break;
				}
				whichUsage = r.nextInt(4);
				switch(whichUsage) {
				case 0:
					SpellPS.singleUse = true;
					spell[3][0] = true;
					break;
				case 1:
					SpellPS.oncePerDay = true;
					spell[3][1] = true;
					break;
				case 2:
					SpellPS.tenPerDay = true;
					spell[3][2] = true;
					break;
				case 3:
					SpellPS.infiniteUse = true;
					spell[3][3] = true;
					break;	
				}
				whichDamage = r.nextInt(4);
				switch(whichDamage) {
				case 0:
					SpellPS.damagesSelf= true;
					spell[4][0] = true;
					break;
				case 1:
					SpellPS.damagesEnemies = true;
					spell[4][1] = true;
					break;
				case 2:
					SpellPS.coneDamage = true;
					spell[4][2] = true;
					break;
				case 3:
					SpellPS.splashDamage = true;
					spell[4][3] = true;
					break;
				}
				break;
			case 3:
				hasAirSpell = true;
				whichSpell = r.nextInt(2);
				switch(whichSpell) {
				case 1:
					SpellPS.blowDown = true;
					spell[2][0] = true;
					break;
				case 2:
					SpellPS.summonWind = true;
					spell[2][1] = true;
					break;
				}
				whichUsage = r.nextInt(4);
				switch(whichUsage) {
				case 0:
					SpellPS.singleUse = true;
					spell[3][0] = true;
					break;
				case 1:
					SpellPS.oncePerDay = true;
					spell[3][1] = true;
					break;
				case 2:
					SpellPS.tenPerDay = true;
					spell[3][2] = true;
					break;
				case 3:
					SpellPS.infiniteUse = true;
					spell[3][3] = true;
					break;	
				}
				whichDamage = r.nextInt(4);
				switch(whichDamage) {
				case 0:
					SpellPS.damagesSelf= true;
					spell[4][0] = true;
					break;
				case 1:
					SpellPS.damagesEnemies = true;
					spell[4][1] = true;
					break;
				case 2:
					SpellPS.coneDamage = true;
					spell[4][2] = true;
					break;
				case 3:
					SpellPS.splashDamage = true;
					spell[4][3] = true;
					break;	
				}
				break;
			}
		}
	public static void spellOut() {
		if (spell[0][0] == true) {
			a = "Firetouch";
		}
		if (spell[0][1] == true) {
			a = "Fireball";
		}
		if (spell[0][2] == true) {
			a = "Firesummon";
		}
		if (spell[1][0] == true) {
			a = "Extinguish";
		}
		if (spell[1][1] == true) {
			a = "Waterball";
		}
		if (spell[1][2] == true) {
			a = "Watersummon";
		}
		if (spell[2][0] == true) {
			a = "Blowdown";
		}
		if (spell[2][1] == true) {
			a = "Summonupdraft";
		}
		if (spell[3][0] == true) {
			d = "Singleuse";
		}
		if (spell[3][1] == true) {
			d = "1/Day";
		}
		if (spell[3][2] == true) {
			d = "10/Day";
		}
		if (spell[3][3] == true) {
			d = "Infinite";
		}
		if (spell[3][0] == true) {
			e = "Damageself";
		}
		if (spell[3][1] == true) {
			e = "Damage1";
		}
		if (spell[3][2] == true) {
			e = "Splash";
		}
		if (spell[3][3] == true) {
			e = "Cone";
		}
		Frame.setAnnouncement(Color.BLUE, a+d+e);
		
	}
}
