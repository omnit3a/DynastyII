package src;

public class LevelGen {
	
	public static void gen(int treeFrequency, int enemyFrequency){
		try {
		for (int i = 0 ; i < treeFrequency ; i++) {
			genWalls();
			fillIn();
		}
		for (int j = 0; j < enemyFrequency; j++) {
			LevelGen.genEnemies();
		}
		
		} catch (Exception e4) {
			
		}
		Elevation.ElevationMap();
	}
	public static void genUpper(int treeFrequency, int enemyFrequency){
		try {
			for (int i = 0 ; i < treeFrequency ; i++) {
				topDropGen();
				topCliffGen();
			}
		for (int j = 0; j < enemyFrequency; j++) {
			topTreeGen();
		}
		
		} catch (Exception e4) {
			
		}
		for (int i = 0 ; i < 19 ; i++) {
			Main.world[19][i] = " ";
		}
	}
	
	public static void genLower() {
				for (int n = 0; n < 19 ; n++) {
					for (int m = 0; m < 19 ; m++) {
						if (Main.worldElevationMap[n][m] == 0) {
							Main.world[n][m] = "▒";
							Main.printWorld();
							continue;
						}
					}
				}
				for (int n = 0; n < 19 ; n++) {
					for (int m = 0; m < 19 ; m++) {
						if (Main.world[n][m] == "▒") {
							Main.world[n][m] = "5";
							Main.printWorld();
							continue;
						}
					}
				}
				for (int n = 0; n < 19 ; n++) {
					for (int m = 0; m < 19 ; m++) {
						if (Main.world[n][m] == ".") {
							Main.world[n][m] = "▒";
							Main.printWorld();
							continue;
						}
					}
				}
				for (int n = 0; n < 19 ; n++) {
					for (int m = 0; m < 19 ; m++) {
						if (Main.world[n][m] == "5") {
							Main.world[n][m] = ".";
							Main.printWorld();
							continue;
						}
					}
				}
				for (int j = 0; j < 5; j++) {
					LevelGen.genEnemies();
				}
	}
	
	public static void genWalls() {
		int wallX = Frame.r.nextInt(20);
		int wallY = Frame.r.nextInt(20);
		
		if (Main.world[wallY][wallX] == "." && (Main.world[wallY+1][wallX+1] != "▒" && Main.world[wallY-1][wallX-1] != "▒" && Main.world[wallY+1][wallX-1] != "▒" && Main.world[wallY-1][wallX+1] != "▒")) {
			Main.world[wallY][wallX] = "▒";
			
			} else {
				genWalls();
				
			}
	}
	public static void genForest() {
		int wallX = Frame.r.nextInt(20);
		int wallY = Frame.r.nextInt(20);
		
		if (Main.world[wallY][wallX] == "." && (Main.world[wallY+1][wallX+1] != "♣" && Main.world[wallY-1][wallX-1] != "♣" && Main.world[wallY+1][wallX-1] != "♣" && Main.world[wallY-1][wallX+1] != "♣")) {
			Main.world[wallY][wallX] = "♣";
			} else {
				genForest();
			}
	}
	public static void genEnemies() {
		int enemyX = Frame.r.nextInt(20);
		int enemyY = Frame.r.nextInt(20);
		
		if (Main.world[enemyY][enemyX] == "." && (enemyX != 0 && enemyY != 0 && enemyX != 19 && enemyY != 19)) {
			Main.world[enemyY][enemyX] ="Ω";
		} else if (enemyX == 0 || enemyY == 0){
			genEnemies();
		}
	}
	
	public static void fillIn(){
		for (int i = 0 ; i < 20 ; i++) {
			for (int j = 0 ; j < 20 ; j++) {
				if (i >= 1 && i < 19 && j >= 1 && j < 19) {
					if (Main.world[i][j+1] == "▒" && Main.world[i][j-1] == "▒") {
						Main.world[i][j] = "▒";
						continue;
					}
					if (Main.world[i+1][j] == "▒" && Main.world[i-1][j] == "▒") {
						Main.world[i][j] = "▒";
						continue;
					}
				}
			}
		}
	}
	
	
	
	public static void topTreeGen() {
		for (int i = 0 ; i < 20 ; i++) {
			for (int j = 0 ; j < 20 ; j++) {
				if (i >= 1 && i < 19 && j >= 1 && j < 19) {
					if (Main.world[i+1][j+1] == "." && Main.world[i-1][j-1] == "." && Main.world[i+1][j-1] == "." && Main.world[i-1][j+1] == ".") {
						Main.world[i][j] = "♣";
						continue;
					}
				}
			}
		}
	}
	public static void topCliffGen() {
		for (int i = 0 ; i < 20 ; i++) {
			for (int j = 0 ; j < 20 ; j++) {
				if (Main.worldElevationMap[i][j] == 1) {
					Main.world[i][j] = "C";
				}
			}
		}
	}
	public static void topDropGen() {
		for (int i = 0 ; i < 20 ; i++) {
			for (int j = 0 ; j < 20 ; j++) {
				if (Main.worldElevationMap[i][j] == 0) {
					Main.world[i][j] = " ";
					Main.worldElevationMap[i][j] = 0;
				}
			}
		}
	}
	public static void bottomUpGen1() {
		for (int i = 0 ; i < 20 ; i++) {
			for (int j = 0 ; j < 20 ; j++) {
				if (Main.world[i][j] == " ") {
					Main.world[i][j] = "5";
					continue;
				}
			}
		}
	}
	
}
