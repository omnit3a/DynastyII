package src;

public class VillageGen {
	public static int houseX;
	public static int houseY;
	public static void Gen() {
		houseX = Frame.r.nextInt(20);
		houseY = Frame.r.nextInt(20);
			if ((houseX+5 <= 19 && houseX > 0) && (houseY+5 <= 19 && houseY > 0)) {
				Main.world[houseY][houseX] = "▒";
				Main.world[houseY+1][houseX] = "▒";
				Main.world[houseY+2][houseX] = ".";
				Main.world[houseY][houseX+2] = ".";
				Main.world[houseY+4][houseX+2] = ".";
				Main.world[houseY+2][houseX+4] = ".";
				Main.world[houseY][houseX+1] = "▒";
				Main.world[houseY+3][houseX] = "▒";
				Main.world[houseY][houseX+3] = "▒";
				Main.world[houseY+4][houseX] = "▒";
				Main.world[houseY][houseX+4] = "▒";
				Main.world[houseY+1][houseX+4] = "▒";
				Main.world[houseY+4][houseX+1] = "▒";
				Main.world[houseY+4][houseX+4] = "▒";
				Main.world[houseY+3][houseX+4] = "▒";
				Main.world[houseY+4][houseX+3] = "▒";
			} else {
				Gen();
			}
	}
}
